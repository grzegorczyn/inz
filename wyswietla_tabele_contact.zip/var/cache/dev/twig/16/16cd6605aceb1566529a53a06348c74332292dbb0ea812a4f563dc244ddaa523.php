<?php

/* default/register2.html.twig */
class __TwigTemplate_64bb05d85338a796459aabad9cd9900184a99b3e70537ed5f8cf513cc9f049d3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_34c6b97eaf6cba434747d9b0ef711d51348d488cbf7d8a0ef9a6e56a2f5f2337 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_34c6b97eaf6cba434747d9b0ef711d51348d488cbf7d8a0ef9a6e56a2f5f2337->enter($__internal_34c6b97eaf6cba434747d9b0ef711d51348d488cbf7d8a0ef9a6e56a2f5f2337_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/register2.html.twig"));

        $__internal_04ac6daa725cf2e924264306b44357dd12c0047c2274379d350332f4229866ec = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_04ac6daa725cf2e924264306b44357dd12c0047c2274379d350332f4229866ec->enter($__internal_04ac6daa725cf2e924264306b44357dd12c0047c2274379d350332f4229866ec_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/register2.html.twig"));

        // line 1
        echo "

";
        // line 3
        $this->displayBlock('title', $context, $blocks);
        // line 4
        echo "
";
        // line 5
        $this->displayBlock('body', $context, $blocks);
        
        $__internal_34c6b97eaf6cba434747d9b0ef711d51348d488cbf7d8a0ef9a6e56a2f5f2337->leave($__internal_34c6b97eaf6cba434747d9b0ef711d51348d488cbf7d8a0ef9a6e56a2f5f2337_prof);

        
        $__internal_04ac6daa725cf2e924264306b44357dd12c0047c2274379d350332f4229866ec->leave($__internal_04ac6daa725cf2e924264306b44357dd12c0047c2274379d350332f4229866ec_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_bb2c8118af8f0ffbfde9baa86482bc93b465cc4dbffca44fc4b7e884220fe9e4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bb2c8118af8f0ffbfde9baa86482bc93b465cc4dbffca44fc4b7e884220fe9e4->enter($__internal_bb2c8118af8f0ffbfde9baa86482bc93b465cc4dbffca44fc4b7e884220fe9e4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_49965c166988397d64b85322f231f44ddceb9a99020408879e4735d045ab8d77 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_49965c166988397d64b85322f231f44ddceb9a99020408879e4735d045ab8d77->enter($__internal_49965c166988397d64b85322f231f44ddceb9a99020408879e4735d045ab8d77_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Rejestracja";
        
        $__internal_49965c166988397d64b85322f231f44ddceb9a99020408879e4735d045ab8d77->leave($__internal_49965c166988397d64b85322f231f44ddceb9a99020408879e4735d045ab8d77_prof);

        
        $__internal_bb2c8118af8f0ffbfde9baa86482bc93b465cc4dbffca44fc4b7e884220fe9e4->leave($__internal_bb2c8118af8f0ffbfde9baa86482bc93b465cc4dbffca44fc4b7e884220fe9e4_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_900faaa0ed9f314799c4037d20d8eb4289fa416a6c2f0f4f2858dd100f8f709a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_900faaa0ed9f314799c4037d20d8eb4289fa416a6c2f0f4f2858dd100f8f709a->enter($__internal_900faaa0ed9f314799c4037d20d8eb4289fa416a6c2f0f4f2858dd100f8f709a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_fc7a71e1cf7bec3b664f2207e700ab4600b1102690621ca1771a79b6fc557183 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fc7a71e1cf7bec3b664f2207e700ab4600b1102690621ca1771a79b6fc557183->enter($__internal_fc7a71e1cf7bec3b664f2207e700ab4600b1102690621ca1771a79b6fc557183_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    ";
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start');
        echo "

";
        // line 8
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'row');
        echo "
    <div id=\"contact_list\" data-prototype=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "contact", array()), "vars", array()), "prototype", array()), 'widget'), "html_attr");
        echo "\">

        ";
        // line 11
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "contact", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
            // line 12
            echo "
";
            // line 13
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($context["row"], 'row');
            echo "
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 15
        echo "    </div>
    ";
        // line 16
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "
";
        
        $__internal_fc7a71e1cf7bec3b664f2207e700ab4600b1102690621ca1771a79b6fc557183->leave($__internal_fc7a71e1cf7bec3b664f2207e700ab4600b1102690621ca1771a79b6fc557183_prof);

        
        $__internal_900faaa0ed9f314799c4037d20d8eb4289fa416a6c2f0f4f2858dd100f8f709a->leave($__internal_900faaa0ed9f314799c4037d20d8eb4289fa416a6c2f0f4f2858dd100f8f709a_prof);

    }

    public function getTemplateName()
    {
        return "default/register2.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  106 => 16,  103 => 15,  95 => 13,  92 => 12,  88 => 11,  83 => 9,  79 => 8,  73 => 6,  64 => 5,  46 => 3,  36 => 5,  33 => 4,  31 => 3,  27 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("

{% block title %}Rejestracja{% endblock %}

{% block body %}
    {{ form_start(form) }}

{{ form_row(form) }}
    <div id=\"contact_list\" data-prototype=\"{{ form_widget(form.contact.vars.prototype)|e('html_attr') }}\">

        {% for row in form.contact %}

{{ form_row(row) }}
        {% endfor %}
    </div>
    {{ form_end(form) }}
{% endblock %}
", "default/register2.html.twig", "C:\\Users\\Natalia\\Provider\\app\\Resources\\views\\default\\register2.html.twig");
    }
}
