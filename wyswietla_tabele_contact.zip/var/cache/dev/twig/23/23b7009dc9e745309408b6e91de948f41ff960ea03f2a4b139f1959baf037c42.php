<?php

/* @Twig/Exception/exception.js.twig */
class __TwigTemplate_0fd10d170bc46b6a255d6efcc54ff1d771c6fbfbcd2365e58d77284806a422f8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d9c65becd70e9ea392425c71f25612f3fac66d6f22bddba9938b37a0ec9da07e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d9c65becd70e9ea392425c71f25612f3fac66d6f22bddba9938b37a0ec9da07e->enter($__internal_d9c65becd70e9ea392425c71f25612f3fac66d6f22bddba9938b37a0ec9da07e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.js.twig"));

        $__internal_3e66cf147097e0fe8e8222fa32acf7f73631e3f4eaf2b06f78988231b4d68e53 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3e66cf147097e0fe8e8222fa32acf7f73631e3f4eaf2b06f78988231b4d68e53->enter($__internal_3e66cf147097e0fe8e8222fa32acf7f73631e3f4eaf2b06f78988231b4d68e53_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_include($this->env, $context, "@Twig/Exception/exception.txt.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
*/
";
        
        $__internal_d9c65becd70e9ea392425c71f25612f3fac66d6f22bddba9938b37a0ec9da07e->leave($__internal_d9c65becd70e9ea392425c71f25612f3fac66d6f22bddba9938b37a0ec9da07e_prof);

        
        $__internal_3e66cf147097e0fe8e8222fa32acf7f73631e3f4eaf2b06f78988231b4d68e53->leave($__internal_3e66cf147097e0fe8e8222fa32acf7f73631e3f4eaf2b06f78988231b4d68e53_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ include('@Twig/Exception/exception.txt.twig', { exception: exception }) }}
*/
", "@Twig/Exception/exception.js.twig", "C:\\Users\\Natalia\\Provider\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception.js.twig");
    }
}
