<?php

/* @Framework/FormTable/button_row.html.php */
class __TwigTemplate_320ec6fa7bec69c462a369b775a9ce8d7128c3fada4d465b5a6418c945378881 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_411f88ecfaa225b9fc909da4ac1989fed5928b43181ec40f3a7494d2e0a45351 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_411f88ecfaa225b9fc909da4ac1989fed5928b43181ec40f3a7494d2e0a45351->enter($__internal_411f88ecfaa225b9fc909da4ac1989fed5928b43181ec40f3a7494d2e0a45351_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        $__internal_fc579a8c3fe381ba29fe8b1cb30b6acd239ca3fff5e09b7a2fc0fe191aaa7a47 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fc579a8c3fe381ba29fe8b1cb30b6acd239ca3fff5e09b7a2fc0fe191aaa7a47->enter($__internal_fc579a8c3fe381ba29fe8b1cb30b6acd239ca3fff5e09b7a2fc0fe191aaa7a47_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        // line 1
        echo "<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form); ?>
    </td>
</tr>
";
        
        $__internal_411f88ecfaa225b9fc909da4ac1989fed5928b43181ec40f3a7494d2e0a45351->leave($__internal_411f88ecfaa225b9fc909da4ac1989fed5928b43181ec40f3a7494d2e0a45351_prof);

        
        $__internal_fc579a8c3fe381ba29fe8b1cb30b6acd239ca3fff5e09b7a2fc0fe191aaa7a47->leave($__internal_fc579a8c3fe381ba29fe8b1cb30b6acd239ca3fff5e09b7a2fc0fe191aaa7a47_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form); ?>
    </td>
</tr>
", "@Framework/FormTable/button_row.html.php", "C:\\Users\\Natalia\\Provider\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\FormTable\\button_row.html.php");
    }
}
