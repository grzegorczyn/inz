<?php

/* @App/register/register.html.twig */
class __TwigTemplate_d2efc51a87025040856aebb6d0689cb6da9aa37854f2ee203a9a77db1e49b44c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3f19884f7639d7b41e54977ea9ea7329a9cc2d8c367644ad96ca7ed181d19bfa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3f19884f7639d7b41e54977ea9ea7329a9cc2d8c367644ad96ca7ed181d19bfa->enter($__internal_3f19884f7639d7b41e54977ea9ea7329a9cc2d8c367644ad96ca7ed181d19bfa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/register/register.html.twig"));

        $__internal_e45f20d68a748d809816a97c4a8da70e89814a41792e6dac6770acd219dea6e3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e45f20d68a748d809816a97c4a8da70e89814a41792e6dac6770acd219dea6e3->enter($__internal_e45f20d68a748d809816a97c4a8da70e89814a41792e6dac6770acd219dea6e3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/register/register.html.twig"));

        // line 1
        echo "

";
        // line 3
        $this->displayBlock('title', $context, $blocks);
        // line 4
        echo "
";
        // line 5
        $this->displayBlock('body', $context, $blocks);
        
        $__internal_3f19884f7639d7b41e54977ea9ea7329a9cc2d8c367644ad96ca7ed181d19bfa->leave($__internal_3f19884f7639d7b41e54977ea9ea7329a9cc2d8c367644ad96ca7ed181d19bfa_prof);

        
        $__internal_e45f20d68a748d809816a97c4a8da70e89814a41792e6dac6770acd219dea6e3->leave($__internal_e45f20d68a748d809816a97c4a8da70e89814a41792e6dac6770acd219dea6e3_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_d3f01ff5397da4a92bb032352e5e7af8f534a825baf2f730fa5970e5a7ce2f79 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d3f01ff5397da4a92bb032352e5e7af8f534a825baf2f730fa5970e5a7ce2f79->enter($__internal_d3f01ff5397da4a92bb032352e5e7af8f534a825baf2f730fa5970e5a7ce2f79_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_1407c9ba02624450bf4b4b4508b337800c0ebf45ba4c94d26bcecb0b55e0f77a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1407c9ba02624450bf4b4b4508b337800c0ebf45ba4c94d26bcecb0b55e0f77a->enter($__internal_1407c9ba02624450bf4b4b4508b337800c0ebf45ba4c94d26bcecb0b55e0f77a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Rejestracja";
        
        $__internal_1407c9ba02624450bf4b4b4508b337800c0ebf45ba4c94d26bcecb0b55e0f77a->leave($__internal_1407c9ba02624450bf4b4b4508b337800c0ebf45ba4c94d26bcecb0b55e0f77a_prof);

        
        $__internal_d3f01ff5397da4a92bb032352e5e7af8f534a825baf2f730fa5970e5a7ce2f79->leave($__internal_d3f01ff5397da4a92bb032352e5e7af8f534a825baf2f730fa5970e5a7ce2f79_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_4c31399b43cc9e3d597880a863a6bb0e84e2fab3de00ca215d7472c9b1ba9e15 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4c31399b43cc9e3d597880a863a6bb0e84e2fab3de00ca215d7472c9b1ba9e15->enter($__internal_4c31399b43cc9e3d597880a863a6bb0e84e2fab3de00ca215d7472c9b1ba9e15_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_98229afe6b65d1e65c5b8bb4c03190f25b272e50f0c61cf466d5604337c673c4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_98229afe6b65d1e65c5b8bb4c03190f25b272e50f0c61cf466d5604337c673c4->enter($__internal_98229afe6b65d1e65c5b8bb4c03190f25b272e50f0c61cf466d5604337c673c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "<h2>welcome</h2>
    ";
        // line 7
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form');
        echo "
";
        
        $__internal_98229afe6b65d1e65c5b8bb4c03190f25b272e50f0c61cf466d5604337c673c4->leave($__internal_98229afe6b65d1e65c5b8bb4c03190f25b272e50f0c61cf466d5604337c673c4_prof);

        
        $__internal_4c31399b43cc9e3d597880a863a6bb0e84e2fab3de00ca215d7472c9b1ba9e15->leave($__internal_4c31399b43cc9e3d597880a863a6bb0e84e2fab3de00ca215d7472c9b1ba9e15_prof);

    }

    public function getTemplateName()
    {
        return "@App/register/register.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  76 => 7,  73 => 6,  64 => 5,  46 => 3,  36 => 5,  33 => 4,  31 => 3,  27 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("

{% block title %}Rejestracja{% endblock %}

{% block body %}
<h2>welcome</h2>
    {{ form(form) }}
{% endblock %}
", "@App/register/register.html.twig", "C:\\Users\\Natalia\\Provider\\src\\AppBundle\\Resources\\views\\register\\register.html.twig");
    }
}
