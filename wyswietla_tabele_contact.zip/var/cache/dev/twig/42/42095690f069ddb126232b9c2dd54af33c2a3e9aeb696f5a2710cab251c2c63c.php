<?php

/* @Framework/Form/textarea_widget.html.php */
class __TwigTemplate_227c1b9c37315cd5bba5f15805197c2b386c526d95d4e55f304550b55c8fcb6d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4ac38ded667b09c87a6d2c034c5477cc873011c5cd7ba489b543d68a38e0cb14 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4ac38ded667b09c87a6d2c034c5477cc873011c5cd7ba489b543d68a38e0cb14->enter($__internal_4ac38ded667b09c87a6d2c034c5477cc873011c5cd7ba489b543d68a38e0cb14_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        $__internal_22545542065943b89ed716f421cc231b8cf5915342306eb2622585a81ede7868 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_22545542065943b89ed716f421cc231b8cf5915342306eb2622585a81ede7868->enter($__internal_22545542065943b89ed716f421cc231b8cf5915342306eb2622585a81ede7868_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        // line 1
        echo "<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
";
        
        $__internal_4ac38ded667b09c87a6d2c034c5477cc873011c5cd7ba489b543d68a38e0cb14->leave($__internal_4ac38ded667b09c87a6d2c034c5477cc873011c5cd7ba489b543d68a38e0cb14_prof);

        
        $__internal_22545542065943b89ed716f421cc231b8cf5915342306eb2622585a81ede7868->leave($__internal_22545542065943b89ed716f421cc231b8cf5915342306eb2622585a81ede7868_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/textarea_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
", "@Framework/Form/textarea_widget.html.php", "C:\\Users\\Natalia\\Provider\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\textarea_widget.html.php");
    }
}
