<?php

/* @Framework/Form/form_end.html.php */
class __TwigTemplate_f6301480ecb664246c94bbb95f82f1642c4e4bdb039577ac82144947d48b500a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c7b2b955d742476efe504bfb682a2dfbd0fb8040b762dbad6a8094f61aeadeb6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c7b2b955d742476efe504bfb682a2dfbd0fb8040b762dbad6a8094f61aeadeb6->enter($__internal_c7b2b955d742476efe504bfb682a2dfbd0fb8040b762dbad6a8094f61aeadeb6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        $__internal_90c2be2a589105efcd8ab599de927936be5ae678ea4bed77ac82c87199f3e819 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_90c2be2a589105efcd8ab599de927936be5ae678ea4bed77ac82c87199f3e819->enter($__internal_90c2be2a589105efcd8ab599de927936be5ae678ea4bed77ac82c87199f3e819_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        // line 1
        echo "<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
";
        
        $__internal_c7b2b955d742476efe504bfb682a2dfbd0fb8040b762dbad6a8094f61aeadeb6->leave($__internal_c7b2b955d742476efe504bfb682a2dfbd0fb8040b762dbad6a8094f61aeadeb6_prof);

        
        $__internal_90c2be2a589105efcd8ab599de927936be5ae678ea4bed77ac82c87199f3e819->leave($__internal_90c2be2a589105efcd8ab599de927936be5ae678ea4bed77ac82c87199f3e819_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_end.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
", "@Framework/Form/form_end.html.php", "C:\\Users\\Natalia\\Provider\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_end.html.php");
    }
}
