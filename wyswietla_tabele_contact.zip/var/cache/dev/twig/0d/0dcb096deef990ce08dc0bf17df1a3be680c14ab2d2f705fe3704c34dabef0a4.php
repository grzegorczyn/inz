<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_a841a3f8a8aab85e180d7087636a0eca7a5fc3c284b569fd1216cff04ad9b418 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_57293196d08b3085ae5f2aa94d1703a876a60a39da1c28dc6f1801d94cce25df = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_57293196d08b3085ae5f2aa94d1703a876a60a39da1c28dc6f1801d94cce25df->enter($__internal_57293196d08b3085ae5f2aa94d1703a876a60a39da1c28dc6f1801d94cce25df_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        $__internal_f4537e6fb4e7026f351661b1d74e8e4fd6f90c34c572090d59f0f8280ffa9239 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f4537e6fb4e7026f351661b1d74e8e4fd6f90c34c572090d59f0f8280ffa9239->enter($__internal_f4537e6fb4e7026f351661b1d74e8e4fd6f90c34c572090d59f0f8280ffa9239_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_57293196d08b3085ae5f2aa94d1703a876a60a39da1c28dc6f1801d94cce25df->leave($__internal_57293196d08b3085ae5f2aa94d1703a876a60a39da1c28dc6f1801d94cce25df_prof);

        
        $__internal_f4537e6fb4e7026f351661b1d74e8e4fd6f90c34c572090d59f0f8280ffa9239->leave($__internal_f4537e6fb4e7026f351661b1d74e8e4fd6f90c34c572090d59f0f8280ffa9239_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Framework/Form/button_label.html.php", "C:\\Users\\Natalia\\Provider\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\button_label.html.php");
    }
}
