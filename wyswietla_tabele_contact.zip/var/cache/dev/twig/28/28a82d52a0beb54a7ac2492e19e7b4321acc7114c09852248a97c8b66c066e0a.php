<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_7edf94b79d278209297326c7f026a6b1e9cc02ce1d52c76e1167c477c5b47c58 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_856e6ad9455e5d4771e89bae48b4509e093e0cf9aa3ec24b557ad455d1776bf8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_856e6ad9455e5d4771e89bae48b4509e093e0cf9aa3ec24b557ad455d1776bf8->enter($__internal_856e6ad9455e5d4771e89bae48b4509e093e0cf9aa3ec24b557ad455d1776bf8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        $__internal_27876cd6fbab07a48bb5cc410f579f2b05448067dafab75492f7f9849a4e1dd6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_27876cd6fbab07a48bb5cc410f579f2b05448067dafab75492f7f9849a4e1dd6->enter($__internal_27876cd6fbab07a48bb5cc410f579f2b05448067dafab75492f7f9849a4e1dd6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_856e6ad9455e5d4771e89bae48b4509e093e0cf9aa3ec24b557ad455d1776bf8->leave($__internal_856e6ad9455e5d4771e89bae48b4509e093e0cf9aa3ec24b557ad455d1776bf8_prof);

        
        $__internal_27876cd6fbab07a48bb5cc410f579f2b05448067dafab75492f7f9849a4e1dd6->leave($__internal_27876cd6fbab07a48bb5cc410f579f2b05448067dafab75492f7f9849a4e1dd6_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->widget(\$form) ?>
", "@Framework/Form/hidden_row.html.php", "C:\\Users\\Natalia\\Provider\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\hidden_row.html.php");
    }
}
