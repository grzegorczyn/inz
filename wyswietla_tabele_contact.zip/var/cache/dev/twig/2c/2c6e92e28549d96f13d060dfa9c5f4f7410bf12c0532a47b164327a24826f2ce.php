<?php

/* @Framework/Form/form_enctype.html.php */
class __TwigTemplate_2500d1089bf8a3c55cde3d2493e1a3d8339a63cabc0cd714bf9322710fed2b83 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9e8c5b4f89e731292425bf2b2b03d352f5e3d74783378b0b4504ee9c80e6c7a4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9e8c5b4f89e731292425bf2b2b03d352f5e3d74783378b0b4504ee9c80e6c7a4->enter($__internal_9e8c5b4f89e731292425bf2b2b03d352f5e3d74783378b0b4504ee9c80e6c7a4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        $__internal_fa50cf7344a6b8d4ad1d24c697b2a04ff3fa2318aa3de87800e7078416bcf825 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fa50cf7344a6b8d4ad1d24c697b2a04ff3fa2318aa3de87800e7078416bcf825->enter($__internal_fa50cf7344a6b8d4ad1d24c697b2a04ff3fa2318aa3de87800e7078416bcf825_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        // line 1
        echo "<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
";
        
        $__internal_9e8c5b4f89e731292425bf2b2b03d352f5e3d74783378b0b4504ee9c80e6c7a4->leave($__internal_9e8c5b4f89e731292425bf2b2b03d352f5e3d74783378b0b4504ee9c80e6c7a4_prof);

        
        $__internal_fa50cf7344a6b8d4ad1d24c697b2a04ff3fa2318aa3de87800e7078416bcf825->leave($__internal_fa50cf7344a6b8d4ad1d24c697b2a04ff3fa2318aa3de87800e7078416bcf825_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_enctype.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
", "@Framework/Form/form_enctype.html.php", "C:\\Users\\Natalia\\Provider\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_enctype.html.php");
    }
}
