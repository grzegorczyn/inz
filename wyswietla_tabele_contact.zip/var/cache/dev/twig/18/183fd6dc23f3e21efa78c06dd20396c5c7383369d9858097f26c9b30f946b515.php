<?php

/* bootstrap_4_layout.html.twig */
class __TwigTemplate_67101549a9f81724de213a0599e5c33752b2362f097607ece312f9e3a3089808 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $_trait_0 = $this->loadTemplate("bootstrap_base_layout.html.twig", "bootstrap_4_layout.html.twig", 1);
        // line 1
        if (!$_trait_0->isTraitable()) {
            throw new Twig_Error_Runtime('Template "'."bootstrap_base_layout.html.twig".'" cannot be used as a trait.');
        }
        $_trait_0_blocks = $_trait_0->getBlocks();

        $this->traits = $_trait_0_blocks;

        $this->blocks = array_merge(
            $this->traits,
            array(
                'money_widget' => array($this, 'block_money_widget'),
                'datetime_widget' => array($this, 'block_datetime_widget'),
                'date_widget' => array($this, 'block_date_widget'),
                'time_widget' => array($this, 'block_time_widget'),
                'dateinterval_widget' => array($this, 'block_dateinterval_widget'),
                'percent_widget' => array($this, 'block_percent_widget'),
                'form_widget_simple' => array($this, 'block_form_widget_simple'),
                'widget_attributes' => array($this, 'block_widget_attributes'),
                'button_widget' => array($this, 'block_button_widget'),
                'checkbox_widget' => array($this, 'block_checkbox_widget'),
                'radio_widget' => array($this, 'block_radio_widget'),
                'choice_widget_expanded' => array($this, 'block_choice_widget_expanded'),
                'form_label' => array($this, 'block_form_label'),
                'checkbox_radio_label' => array($this, 'block_checkbox_radio_label'),
                'form_row' => array($this, 'block_form_row'),
                'form_errors' => array($this, 'block_form_errors'),
            )
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9b9f0105cc7898d95c3e3a7f1a85aa7fee204ebf78f30004b56efaa7bbed1fa2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9b9f0105cc7898d95c3e3a7f1a85aa7fee204ebf78f30004b56efaa7bbed1fa2->enter($__internal_9b9f0105cc7898d95c3e3a7f1a85aa7fee204ebf78f30004b56efaa7bbed1fa2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "bootstrap_4_layout.html.twig"));

        $__internal_62793cbae00d65fe16796a2250443f8d987ddbec6e1d864eea9e8cfd0caf650d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_62793cbae00d65fe16796a2250443f8d987ddbec6e1d864eea9e8cfd0caf650d->enter($__internal_62793cbae00d65fe16796a2250443f8d987ddbec6e1d864eea9e8cfd0caf650d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "bootstrap_4_layout.html.twig"));

        // line 2
        echo "
";
        // line 4
        echo "
";
        // line 5
        $this->displayBlock('money_widget', $context, $blocks);
        // line 12
        echo "
";
        // line 13
        $this->displayBlock('datetime_widget', $context, $blocks);
        // line 20
        echo "
";
        // line 21
        $this->displayBlock('date_widget', $context, $blocks);
        // line 28
        echo "
";
        // line 29
        $this->displayBlock('time_widget', $context, $blocks);
        // line 36
        echo "
";
        // line 37
        $this->displayBlock('dateinterval_widget', $context, $blocks);
        // line 44
        echo "
";
        // line 45
        $this->displayBlock('percent_widget', $context, $blocks);
        // line 52
        echo "
";
        // line 53
        $this->displayBlock('form_widget_simple', $context, $blocks);
        // line 60
        $this->displayBlock('widget_attributes', $context, $blocks);
        // line 67
        $this->displayBlock('button_widget', $context, $blocks);
        // line 71
        echo "
";
        // line 72
        $this->displayBlock('checkbox_widget', $context, $blocks);
        // line 83
        echo "
";
        // line 84
        $this->displayBlock('radio_widget', $context, $blocks);
        // line 95
        echo "
";
        // line 96
        $this->displayBlock('choice_widget_expanded', $context, $blocks);
        // line 120
        echo "
";
        // line 122
        echo "
";
        // line 123
        $this->displayBlock('form_label', $context, $blocks);
        // line 132
        echo "
";
        // line 133
        $this->displayBlock('checkbox_radio_label', $context, $blocks);
        // line 158
        echo "
";
        // line 160
        echo "
";
        // line 161
        $this->displayBlock('form_row', $context, $blocks);
        // line 171
        echo "
";
        // line 173
        echo "
";
        // line 174
        $this->displayBlock('form_errors', $context, $blocks);
        
        $__internal_9b9f0105cc7898d95c3e3a7f1a85aa7fee204ebf78f30004b56efaa7bbed1fa2->leave($__internal_9b9f0105cc7898d95c3e3a7f1a85aa7fee204ebf78f30004b56efaa7bbed1fa2_prof);

        
        $__internal_62793cbae00d65fe16796a2250443f8d987ddbec6e1d864eea9e8cfd0caf650d->leave($__internal_62793cbae00d65fe16796a2250443f8d987ddbec6e1d864eea9e8cfd0caf650d_prof);

    }

    // line 5
    public function block_money_widget($context, array $blocks = array())
    {
        $__internal_09f5a4ac917da52740e5dbc92ef47ecabe6c057a00bc883b54643aab1693d4b3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_09f5a4ac917da52740e5dbc92ef47ecabe6c057a00bc883b54643aab1693d4b3->enter($__internal_09f5a4ac917da52740e5dbc92ef47ecabe6c057a00bc883b54643aab1693d4b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "money_widget"));

        $__internal_b2407f75caeca594e6ae39709a45ebbaf93d2b26348b7099591bfea4adf381f2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b2407f75caeca594e6ae39709a45ebbaf93d2b26348b7099591bfea4adf381f2->enter($__internal_b2407f75caeca594e6ae39709a45ebbaf93d2b26348b7099591bfea4adf381f2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "money_widget"));

        // line 6
        if ( !($context["valid"] ?? $this->getContext($context, "valid"))) {
            // line 7
            echo "        ";
            $context["group_class"] = " form-control is-invalid";
            // line 8
            echo "        ";
            $context["valid"] = true;
            // line 9
            echo "    ";
        }
        // line 10
        $this->displayParentBlock("money_widget", $context, $blocks);
        
        $__internal_b2407f75caeca594e6ae39709a45ebbaf93d2b26348b7099591bfea4adf381f2->leave($__internal_b2407f75caeca594e6ae39709a45ebbaf93d2b26348b7099591bfea4adf381f2_prof);

        
        $__internal_09f5a4ac917da52740e5dbc92ef47ecabe6c057a00bc883b54643aab1693d4b3->leave($__internal_09f5a4ac917da52740e5dbc92ef47ecabe6c057a00bc883b54643aab1693d4b3_prof);

    }

    // line 13
    public function block_datetime_widget($context, array $blocks = array())
    {
        $__internal_16afb0d4e7b63cb6b1540c924b3d3f8e3e4a3cf2df6039c42d0181138d5176de = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_16afb0d4e7b63cb6b1540c924b3d3f8e3e4a3cf2df6039c42d0181138d5176de->enter($__internal_16afb0d4e7b63cb6b1540c924b3d3f8e3e4a3cf2df6039c42d0181138d5176de_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datetime_widget"));

        $__internal_a6d75c652de5ead8a9bb76625da645ee29adde30f9f10ec4ec96791b52e331d0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a6d75c652de5ead8a9bb76625da645ee29adde30f9f10ec4ec96791b52e331d0->enter($__internal_a6d75c652de5ead8a9bb76625da645ee29adde30f9f10ec4ec96791b52e331d0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datetime_widget"));

        // line 14
        if (((($context["widget"] ?? $this->getContext($context, "widget")) != "single_text") &&  !($context["valid"] ?? $this->getContext($context, "valid")))) {
            // line 15
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-control is-invalid"))));
            // line 16
            $context["valid"] = true;
        }
        // line 18
        $this->displayParentBlock("datetime_widget", $context, $blocks);
        
        $__internal_a6d75c652de5ead8a9bb76625da645ee29adde30f9f10ec4ec96791b52e331d0->leave($__internal_a6d75c652de5ead8a9bb76625da645ee29adde30f9f10ec4ec96791b52e331d0_prof);

        
        $__internal_16afb0d4e7b63cb6b1540c924b3d3f8e3e4a3cf2df6039c42d0181138d5176de->leave($__internal_16afb0d4e7b63cb6b1540c924b3d3f8e3e4a3cf2df6039c42d0181138d5176de_prof);

    }

    // line 21
    public function block_date_widget($context, array $blocks = array())
    {
        $__internal_56e2bbf611f98efe452b969d75c89d92b367cfcb8598193ecb17b4ae4b83e536 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_56e2bbf611f98efe452b969d75c89d92b367cfcb8598193ecb17b4ae4b83e536->enter($__internal_56e2bbf611f98efe452b969d75c89d92b367cfcb8598193ecb17b4ae4b83e536_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_widget"));

        $__internal_0e043d29fc676e32d4c7a639e2d56a842eface56ddce34ec92d1d6362edf5626 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0e043d29fc676e32d4c7a639e2d56a842eface56ddce34ec92d1d6362edf5626->enter($__internal_0e043d29fc676e32d4c7a639e2d56a842eface56ddce34ec92d1d6362edf5626_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_widget"));

        // line 22
        if (((($context["widget"] ?? $this->getContext($context, "widget")) != "single_text") &&  !($context["valid"] ?? $this->getContext($context, "valid")))) {
            // line 23
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-control is-invalid"))));
            // line 24
            $context["valid"] = true;
        }
        // line 26
        $this->displayParentBlock("date_widget", $context, $blocks);
        
        $__internal_0e043d29fc676e32d4c7a639e2d56a842eface56ddce34ec92d1d6362edf5626->leave($__internal_0e043d29fc676e32d4c7a639e2d56a842eface56ddce34ec92d1d6362edf5626_prof);

        
        $__internal_56e2bbf611f98efe452b969d75c89d92b367cfcb8598193ecb17b4ae4b83e536->leave($__internal_56e2bbf611f98efe452b969d75c89d92b367cfcb8598193ecb17b4ae4b83e536_prof);

    }

    // line 29
    public function block_time_widget($context, array $blocks = array())
    {
        $__internal_8a587eda292fb09466b506c82a568a0e3bfd98b4a4e87bee59e3f74f8f96e43d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8a587eda292fb09466b506c82a568a0e3bfd98b4a4e87bee59e3f74f8f96e43d->enter($__internal_8a587eda292fb09466b506c82a568a0e3bfd98b4a4e87bee59e3f74f8f96e43d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "time_widget"));

        $__internal_a9d34c55fa03748db861584f8ae692e255bd4b6e5a0520c266ab3f636d3d5668 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a9d34c55fa03748db861584f8ae692e255bd4b6e5a0520c266ab3f636d3d5668->enter($__internal_a9d34c55fa03748db861584f8ae692e255bd4b6e5a0520c266ab3f636d3d5668_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "time_widget"));

        // line 30
        if (((($context["widget"] ?? $this->getContext($context, "widget")) != "single_text") &&  !($context["valid"] ?? $this->getContext($context, "valid")))) {
            // line 31
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-control is-invalid"))));
            // line 32
            $context["valid"] = true;
        }
        // line 34
        $this->displayParentBlock("time_widget", $context, $blocks);
        
        $__internal_a9d34c55fa03748db861584f8ae692e255bd4b6e5a0520c266ab3f636d3d5668->leave($__internal_a9d34c55fa03748db861584f8ae692e255bd4b6e5a0520c266ab3f636d3d5668_prof);

        
        $__internal_8a587eda292fb09466b506c82a568a0e3bfd98b4a4e87bee59e3f74f8f96e43d->leave($__internal_8a587eda292fb09466b506c82a568a0e3bfd98b4a4e87bee59e3f74f8f96e43d_prof);

    }

    // line 37
    public function block_dateinterval_widget($context, array $blocks = array())
    {
        $__internal_5fc759f9c7ac124b337ac7a4eb9745a82769e09577bd570197ca728068329085 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5fc759f9c7ac124b337ac7a4eb9745a82769e09577bd570197ca728068329085->enter($__internal_5fc759f9c7ac124b337ac7a4eb9745a82769e09577bd570197ca728068329085_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "dateinterval_widget"));

        $__internal_de00d781c8511eeac6c879be77a682e2fe8b0ba08fb3bdb836d972025ef1b4b7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_de00d781c8511eeac6c879be77a682e2fe8b0ba08fb3bdb836d972025ef1b4b7->enter($__internal_de00d781c8511eeac6c879be77a682e2fe8b0ba08fb3bdb836d972025ef1b4b7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "dateinterval_widget"));

        // line 38
        if (((($context["widget"] ?? $this->getContext($context, "widget")) != "single_text") &&  !($context["valid"] ?? $this->getContext($context, "valid")))) {
            // line 39
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-control is-invalid"))));
            // line 40
            $context["valid"] = true;
        }
        // line 42
        $this->displayParentBlock("dateinterval_widget", $context, $blocks);
        
        $__internal_de00d781c8511eeac6c879be77a682e2fe8b0ba08fb3bdb836d972025ef1b4b7->leave($__internal_de00d781c8511eeac6c879be77a682e2fe8b0ba08fb3bdb836d972025ef1b4b7_prof);

        
        $__internal_5fc759f9c7ac124b337ac7a4eb9745a82769e09577bd570197ca728068329085->leave($__internal_5fc759f9c7ac124b337ac7a4eb9745a82769e09577bd570197ca728068329085_prof);

    }

    // line 45
    public function block_percent_widget($context, array $blocks = array())
    {
        $__internal_168979027f77de8250268f3d13e4c6f6934086e68b05b511ca5175f3e6dbbd15 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_168979027f77de8250268f3d13e4c6f6934086e68b05b511ca5175f3e6dbbd15->enter($__internal_168979027f77de8250268f3d13e4c6f6934086e68b05b511ca5175f3e6dbbd15_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "percent_widget"));

        $__internal_e1845921755115331edc60be51da903c6513c8e6b1d2a7caf17185dc290fc6a8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e1845921755115331edc60be51da903c6513c8e6b1d2a7caf17185dc290fc6a8->enter($__internal_e1845921755115331edc60be51da903c6513c8e6b1d2a7caf17185dc290fc6a8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "percent_widget"));

        // line 46
        echo "<div class=\"input-group";
        echo (( !($context["valid"] ?? $this->getContext($context, "valid"))) ? (" form-control is-invalid") : (""));
        echo "\">
        ";
        // line 47
        $context["valid"] = true;
        // line 48
        $this->displayBlock("form_widget_simple", $context, $blocks);
        // line 49
        echo "<span class=\"input-group-addon\">%</span>
    </div>";
        
        $__internal_e1845921755115331edc60be51da903c6513c8e6b1d2a7caf17185dc290fc6a8->leave($__internal_e1845921755115331edc60be51da903c6513c8e6b1d2a7caf17185dc290fc6a8_prof);

        
        $__internal_168979027f77de8250268f3d13e4c6f6934086e68b05b511ca5175f3e6dbbd15->leave($__internal_168979027f77de8250268f3d13e4c6f6934086e68b05b511ca5175f3e6dbbd15_prof);

    }

    // line 53
    public function block_form_widget_simple($context, array $blocks = array())
    {
        $__internal_a5b31873c1bc87ec8b4871e29980739583fd2f899af244572b42410dece91116 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a5b31873c1bc87ec8b4871e29980739583fd2f899af244572b42410dece91116->enter($__internal_a5b31873c1bc87ec8b4871e29980739583fd2f899af244572b42410dece91116_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_widget_simple"));

        $__internal_854844e1222374204152ea4219c3aa26089bab2f38bdc65d34951561a9dacc58 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_854844e1222374204152ea4219c3aa26089bab2f38bdc65d34951561a9dacc58->enter($__internal_854844e1222374204152ea4219c3aa26089bab2f38bdc65d34951561a9dacc58_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_widget_simple"));

        // line 54
        if (( !array_key_exists("type", $context) || (($context["type"] ?? $this->getContext($context, "type")) != "hidden"))) {
            // line 55
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter((((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-control") . (((((array_key_exists("type", $context)) ? (_twig_default_filter(($context["type"] ?? $this->getContext($context, "type")), "")) : ("")) == "file")) ? ("-file") : (""))))));
        }
        // line 57
        $this->displayParentBlock("form_widget_simple", $context, $blocks);
        
        $__internal_854844e1222374204152ea4219c3aa26089bab2f38bdc65d34951561a9dacc58->leave($__internal_854844e1222374204152ea4219c3aa26089bab2f38bdc65d34951561a9dacc58_prof);

        
        $__internal_a5b31873c1bc87ec8b4871e29980739583fd2f899af244572b42410dece91116->leave($__internal_a5b31873c1bc87ec8b4871e29980739583fd2f899af244572b42410dece91116_prof);

    }

    // line 60
    public function block_widget_attributes($context, array $blocks = array())
    {
        $__internal_6ca6adede10f88681d2865ddee965ab7b55819d2b26abf6161e11094617f72bc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6ca6adede10f88681d2865ddee965ab7b55819d2b26abf6161e11094617f72bc->enter($__internal_6ca6adede10f88681d2865ddee965ab7b55819d2b26abf6161e11094617f72bc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "widget_attributes"));

        $__internal_7b7ae44be4ea579463a3832cd91c446d51f8ad19ef3933aa9d872b20e0f87fa2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7b7ae44be4ea579463a3832cd91c446d51f8ad19ef3933aa9d872b20e0f87fa2->enter($__internal_7b7ae44be4ea579463a3832cd91c446d51f8ad19ef3933aa9d872b20e0f87fa2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "widget_attributes"));

        // line 61
        if ( !($context["valid"] ?? $this->getContext($context, "valid"))) {
            // line 62
            echo "        ";
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-control is-invalid"))));
            // line 63
            echo "    ";
        }
        // line 64
        $this->displayParentBlock("widget_attributes", $context, $blocks);
        
        $__internal_7b7ae44be4ea579463a3832cd91c446d51f8ad19ef3933aa9d872b20e0f87fa2->leave($__internal_7b7ae44be4ea579463a3832cd91c446d51f8ad19ef3933aa9d872b20e0f87fa2_prof);

        
        $__internal_6ca6adede10f88681d2865ddee965ab7b55819d2b26abf6161e11094617f72bc->leave($__internal_6ca6adede10f88681d2865ddee965ab7b55819d2b26abf6161e11094617f72bc_prof);

    }

    // line 67
    public function block_button_widget($context, array $blocks = array())
    {
        $__internal_e94dd308bd253544ad0ae1086d90dba1c7dc260553646edd2222f44e5a99ecef = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e94dd308bd253544ad0ae1086d90dba1c7dc260553646edd2222f44e5a99ecef->enter($__internal_e94dd308bd253544ad0ae1086d90dba1c7dc260553646edd2222f44e5a99ecef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "button_widget"));

        $__internal_55a192300b95a7a9ad9b28e61e910ef9caac1cc70333e5ba30a7ba04f8b3f257 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_55a192300b95a7a9ad9b28e61e910ef9caac1cc70333e5ba30a7ba04f8b3f257->enter($__internal_55a192300b95a7a9ad9b28e61e910ef9caac1cc70333e5ba30a7ba04f8b3f257_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "button_widget"));

        // line 68
        $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "btn-secondary")) : ("btn-secondary")) . " btn"))));
        // line 69
        $this->displayParentBlock("button_widget", $context, $blocks);
        
        $__internal_55a192300b95a7a9ad9b28e61e910ef9caac1cc70333e5ba30a7ba04f8b3f257->leave($__internal_55a192300b95a7a9ad9b28e61e910ef9caac1cc70333e5ba30a7ba04f8b3f257_prof);

        
        $__internal_e94dd308bd253544ad0ae1086d90dba1c7dc260553646edd2222f44e5a99ecef->leave($__internal_e94dd308bd253544ad0ae1086d90dba1c7dc260553646edd2222f44e5a99ecef_prof);

    }

    // line 72
    public function block_checkbox_widget($context, array $blocks = array())
    {
        $__internal_babd54e3066a9d9a764d726c03d5338592a3f7ca2db510d38bfa62abb976339d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_babd54e3066a9d9a764d726c03d5338592a3f7ca2db510d38bfa62abb976339d->enter($__internal_babd54e3066a9d9a764d726c03d5338592a3f7ca2db510d38bfa62abb976339d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_widget"));

        $__internal_4f5888ebbdaca3a36246404e851f747a6b06b3b3fe63b6495638d7a92def1da1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4f5888ebbdaca3a36246404e851f747a6b06b3b3fe63b6495638d7a92def1da1->enter($__internal_4f5888ebbdaca3a36246404e851f747a6b06b3b3fe63b6495638d7a92def1da1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_widget"));

        // line 73
        $context["parent_label_class"] = ((array_key_exists("parent_label_class", $context)) ? (_twig_default_filter(($context["parent_label_class"] ?? $this->getContext($context, "parent_label_class")), (($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")))) : ((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : (""))));
        // line 74
        $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-check-input"))));
        // line 75
        if (twig_in_filter("checkbox-inline", ($context["parent_label_class"] ?? $this->getContext($context, "parent_label_class")))) {
            // line 76
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label', array("widget" => $this->renderParentBlock("checkbox_widget", $context, $blocks)));
        } else {
            // line 78
            echo "<div class=\"form-check";
            echo (( !($context["valid"] ?? $this->getContext($context, "valid"))) ? (" form-control is-invalid") : (""));
            echo "\">";
            // line 79
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label', array("widget" => $this->renderParentBlock("checkbox_widget", $context, $blocks)));
            // line 80
            echo "</div>";
        }
        
        $__internal_4f5888ebbdaca3a36246404e851f747a6b06b3b3fe63b6495638d7a92def1da1->leave($__internal_4f5888ebbdaca3a36246404e851f747a6b06b3b3fe63b6495638d7a92def1da1_prof);

        
        $__internal_babd54e3066a9d9a764d726c03d5338592a3f7ca2db510d38bfa62abb976339d->leave($__internal_babd54e3066a9d9a764d726c03d5338592a3f7ca2db510d38bfa62abb976339d_prof);

    }

    // line 84
    public function block_radio_widget($context, array $blocks = array())
    {
        $__internal_c5375b68cb4f6c0b8a151e4eb931381b77f12ee29e9b129250be8bf1e7bde1ae = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c5375b68cb4f6c0b8a151e4eb931381b77f12ee29e9b129250be8bf1e7bde1ae->enter($__internal_c5375b68cb4f6c0b8a151e4eb931381b77f12ee29e9b129250be8bf1e7bde1ae_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_widget"));

        $__internal_d93ebae91590f8aa444b9de5763f5a8cdd8796b79f872e7fd1f8b3ef8308f70b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d93ebae91590f8aa444b9de5763f5a8cdd8796b79f872e7fd1f8b3ef8308f70b->enter($__internal_d93ebae91590f8aa444b9de5763f5a8cdd8796b79f872e7fd1f8b3ef8308f70b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_widget"));

        // line 85
        $context["parent_label_class"] = ((array_key_exists("parent_label_class", $context)) ? (_twig_default_filter(($context["parent_label_class"] ?? $this->getContext($context, "parent_label_class")), (($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")))) : ((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : (""))));
        // line 86
        $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-check-input"))));
        // line 87
        if (twig_in_filter("radio-inline", ($context["parent_label_class"] ?? $this->getContext($context, "parent_label_class")))) {
            // line 88
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label', array("widget" => $this->renderParentBlock("radio_widget", $context, $blocks)));
        } else {
            // line 90
            echo "<div class=\"form-check";
            echo (( !($context["valid"] ?? $this->getContext($context, "valid"))) ? (" form-control is-invalid") : (""));
            echo "\">";
            // line 91
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label', array("widget" => $this->renderParentBlock("radio_widget", $context, $blocks)));
            // line 92
            echo "</div>";
        }
        
        $__internal_d93ebae91590f8aa444b9de5763f5a8cdd8796b79f872e7fd1f8b3ef8308f70b->leave($__internal_d93ebae91590f8aa444b9de5763f5a8cdd8796b79f872e7fd1f8b3ef8308f70b_prof);

        
        $__internal_c5375b68cb4f6c0b8a151e4eb931381b77f12ee29e9b129250be8bf1e7bde1ae->leave($__internal_c5375b68cb4f6c0b8a151e4eb931381b77f12ee29e9b129250be8bf1e7bde1ae_prof);

    }

    // line 96
    public function block_choice_widget_expanded($context, array $blocks = array())
    {
        $__internal_7e36d2396bec08ff2c8e5687ec2c4f60fb737e4cc2d1b0f056658c13e5f2f05b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7e36d2396bec08ff2c8e5687ec2c4f60fb737e4cc2d1b0f056658c13e5f2f05b->enter($__internal_7e36d2396bec08ff2c8e5687ec2c4f60fb737e4cc2d1b0f056658c13e5f2f05b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_widget_expanded"));

        $__internal_6fa22097903280d3350e6ff812ad6bc151b5cc5db7a8acd05927539ce6b0c21e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6fa22097903280d3350e6ff812ad6bc151b5cc5db7a8acd05927539ce6b0c21e->enter($__internal_6fa22097903280d3350e6ff812ad6bc151b5cc5db7a8acd05927539ce6b0c21e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_widget_expanded"));

        // line 97
        if (twig_in_filter("-inline", (($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")))) {
            // line 98
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["form"] ?? $this->getContext($context, "form")));
            foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
                // line 99
                echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($context["child"], 'widget', array("parent_label_class" => (($this->getAttribute(                // line 100
($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")), "translation_domain" =>                 // line 101
($context["choice_translation_domain"] ?? $this->getContext($context, "choice_translation_domain")), "valid" =>                 // line 102
($context["valid"] ?? $this->getContext($context, "valid"))));
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        } else {
            // line 106
            if ( !($context["valid"] ?? $this->getContext($context, "valid"))) {
                // line 107
                $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-control is-invalid"))));
            }
            // line 109
            echo "<div ";
            $this->displayBlock("widget_container_attributes", $context, $blocks);
            echo ">";
            // line 110
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["form"] ?? $this->getContext($context, "form")));
            foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
                // line 111
                echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($context["child"], 'widget', array("parent_label_class" => (($this->getAttribute(                // line 112
($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")), "translation_domain" =>                 // line 113
($context["choice_translation_domain"] ?? $this->getContext($context, "choice_translation_domain")), "valid" => true));
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 117
            echo "</div>";
        }
        
        $__internal_6fa22097903280d3350e6ff812ad6bc151b5cc5db7a8acd05927539ce6b0c21e->leave($__internal_6fa22097903280d3350e6ff812ad6bc151b5cc5db7a8acd05927539ce6b0c21e_prof);

        
        $__internal_7e36d2396bec08ff2c8e5687ec2c4f60fb737e4cc2d1b0f056658c13e5f2f05b->leave($__internal_7e36d2396bec08ff2c8e5687ec2c4f60fb737e4cc2d1b0f056658c13e5f2f05b_prof);

    }

    // line 123
    public function block_form_label($context, array $blocks = array())
    {
        $__internal_7aa6ede117d6f48b0e4ac6e45bbd2d09cc82888409e1317eda59192adde15d8b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7aa6ede117d6f48b0e4ac6e45bbd2d09cc82888409e1317eda59192adde15d8b->enter($__internal_7aa6ede117d6f48b0e4ac6e45bbd2d09cc82888409e1317eda59192adde15d8b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_label"));

        $__internal_f0a2380f5cd4548aeec0ddeae3ae9730a187fea5522784ebc88467048d2d979a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f0a2380f5cd4548aeec0ddeae3ae9730a187fea5522784ebc88467048d2d979a->enter($__internal_f0a2380f5cd4548aeec0ddeae3ae9730a187fea5522784ebc88467048d2d979a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_label"));

        // line 124
        if ((array_key_exists("compound", $context) && ($context["compound"] ?? $this->getContext($context, "compound")))) {
            // line 125
            $context["element"] = "legend";
            // line 126
            $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")) . " col-form-legend"))));
        } else {
            // line 128
            $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")) . " form-control-label"))));
        }
        // line 130
        $this->displayParentBlock("form_label", $context, $blocks);
        
        $__internal_f0a2380f5cd4548aeec0ddeae3ae9730a187fea5522784ebc88467048d2d979a->leave($__internal_f0a2380f5cd4548aeec0ddeae3ae9730a187fea5522784ebc88467048d2d979a_prof);

        
        $__internal_7aa6ede117d6f48b0e4ac6e45bbd2d09cc82888409e1317eda59192adde15d8b->leave($__internal_7aa6ede117d6f48b0e4ac6e45bbd2d09cc82888409e1317eda59192adde15d8b_prof);

    }

    // line 133
    public function block_checkbox_radio_label($context, array $blocks = array())
    {
        $__internal_e0f5849a95b899e3cec89b8c53fda855b9ec89001e630db4166fd7d535869304 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e0f5849a95b899e3cec89b8c53fda855b9ec89001e630db4166fd7d535869304->enter($__internal_e0f5849a95b899e3cec89b8c53fda855b9ec89001e630db4166fd7d535869304_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_radio_label"));

        $__internal_735ceb2d2ca69453424980a0949e1f886cced739328f558e097c6488d6ccd703 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_735ceb2d2ca69453424980a0949e1f886cced739328f558e097c6488d6ccd703->enter($__internal_735ceb2d2ca69453424980a0949e1f886cced739328f558e097c6488d6ccd703_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_radio_label"));

        // line 135
        if (array_key_exists("widget", $context)) {
            // line 136
            $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")) . " form-check-label"))));
            // line 137
            if (($context["required"] ?? $this->getContext($context, "required"))) {
                // line 138
                $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")) . " required"))));
            }
            // line 140
            if (array_key_exists("parent_label_class", $context)) {
                // line 141
                $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => twig_trim_filter((((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")) . " ") . ($context["parent_label_class"] ?? $this->getContext($context, "parent_label_class"))))));
            }
            // line 143
            if (( !(($context["label"] ?? $this->getContext($context, "label")) === false) && twig_test_empty(($context["label"] ?? $this->getContext($context, "label"))))) {
                // line 144
                if ( !twig_test_empty(($context["label_format"] ?? $this->getContext($context, "label_format")))) {
                    // line 145
                    $context["label"] = twig_replace_filter(($context["label_format"] ?? $this->getContext($context, "label_format")), array("%name%" =>                     // line 146
($context["name"] ?? $this->getContext($context, "name")), "%id%" =>                     // line 147
($context["id"] ?? $this->getContext($context, "id"))));
                } else {
                    // line 150
                    $context["label"] = $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->humanize(($context["name"] ?? $this->getContext($context, "name")));
                }
            }
            // line 153
            echo "<label";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["label_attr"] ?? $this->getContext($context, "label_attr")));
            foreach ($context['_seq'] as $context["attrname"] => $context["attrvalue"]) {
                echo " ";
                echo twig_escape_filter($this->env, $context["attrname"], "html", null, true);
                echo "=\"";
                echo twig_escape_filter($this->env, $context["attrvalue"], "html", null, true);
                echo "\"";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['attrname'], $context['attrvalue'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo ">";
            // line 154
            echo ($context["widget"] ?? $this->getContext($context, "widget"));
            echo " ";
            echo twig_escape_filter($this->env, (( !(($context["label"] ?? $this->getContext($context, "label")) === false)) ? ((((($context["translation_domain"] ?? $this->getContext($context, "translation_domain")) === false)) ? (($context["label"] ?? $this->getContext($context, "label"))) : ($this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans(($context["label"] ?? $this->getContext($context, "label")), array(), ($context["translation_domain"] ?? $this->getContext($context, "translation_domain")))))) : ("")), "html", null, true);
            // line 155
            echo "</label>";
        }
        
        $__internal_735ceb2d2ca69453424980a0949e1f886cced739328f558e097c6488d6ccd703->leave($__internal_735ceb2d2ca69453424980a0949e1f886cced739328f558e097c6488d6ccd703_prof);

        
        $__internal_e0f5849a95b899e3cec89b8c53fda855b9ec89001e630db4166fd7d535869304->leave($__internal_e0f5849a95b899e3cec89b8c53fda855b9ec89001e630db4166fd7d535869304_prof);

    }

    // line 161
    public function block_form_row($context, array $blocks = array())
    {
        $__internal_a345c9e13fa296b61899ddf1a0414d6cc778c99580b9e06e76b4d14f9712970e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a345c9e13fa296b61899ddf1a0414d6cc778c99580b9e06e76b4d14f9712970e->enter($__internal_a345c9e13fa296b61899ddf1a0414d6cc778c99580b9e06e76b4d14f9712970e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_row"));

        $__internal_c675967aa2d193e4b7382c4ccfc7515245df27d8be51b9bc108e4d02710ae5f9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c675967aa2d193e4b7382c4ccfc7515245df27d8be51b9bc108e4d02710ae5f9->enter($__internal_c675967aa2d193e4b7382c4ccfc7515245df27d8be51b9bc108e4d02710ae5f9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_row"));

        // line 162
        if ((array_key_exists("compound", $context) && ($context["compound"] ?? $this->getContext($context, "compound")))) {
            // line 163
            $context["element"] = "fieldset";
        }
        // line 165
        echo "<";
        echo twig_escape_filter($this->env, ((array_key_exists("element", $context)) ? (_twig_default_filter(($context["element"] ?? $this->getContext($context, "element")), "div")) : ("div")), "html", null, true);
        echo " class=\"form-group\">";
        // line 166
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label');
        // line 167
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 168
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
        // line 169
        echo "</";
        echo twig_escape_filter($this->env, ((array_key_exists("element", $context)) ? (_twig_default_filter(($context["element"] ?? $this->getContext($context, "element")), "div")) : ("div")), "html", null, true);
        echo ">";
        
        $__internal_c675967aa2d193e4b7382c4ccfc7515245df27d8be51b9bc108e4d02710ae5f9->leave($__internal_c675967aa2d193e4b7382c4ccfc7515245df27d8be51b9bc108e4d02710ae5f9_prof);

        
        $__internal_a345c9e13fa296b61899ddf1a0414d6cc778c99580b9e06e76b4d14f9712970e->leave($__internal_a345c9e13fa296b61899ddf1a0414d6cc778c99580b9e06e76b4d14f9712970e_prof);

    }

    // line 174
    public function block_form_errors($context, array $blocks = array())
    {
        $__internal_db3c9e1e7a662233142ea2f493f033dc8286d4173af57655621494ee0c20600e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_db3c9e1e7a662233142ea2f493f033dc8286d4173af57655621494ee0c20600e->enter($__internal_db3c9e1e7a662233142ea2f493f033dc8286d4173af57655621494ee0c20600e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_errors"));

        $__internal_3fab6af8bafe6506c9cdf87059d676cb406449b44052cfadbddef7513e026a70 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3fab6af8bafe6506c9cdf87059d676cb406449b44052cfadbddef7513e026a70->enter($__internal_3fab6af8bafe6506c9cdf87059d676cb406449b44052cfadbddef7513e026a70_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_errors"));

        // line 175
        if ((twig_length_filter($this->env, ($context["errors"] ?? $this->getContext($context, "errors"))) > 0)) {
            // line 176
            echo "<div class=\"";
            if ($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "parent", array())) {
                echo "invalid-feedback";
            } else {
                echo "alert alert-danger";
            }
            echo "\">
        <ul class=\"list-unstyled mb-0\">";
            // line 178
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["errors"] ?? $this->getContext($context, "errors")));
            foreach ($context['_seq'] as $context["_key"] => $context["error"]) {
                // line 179
                echo "<li>";
                echo twig_escape_filter($this->env, $this->getAttribute($context["error"], "message", array()), "html", null, true);
                echo "</li>";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['error'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 181
            echo "</ul>
    </div>";
        }
        
        $__internal_3fab6af8bafe6506c9cdf87059d676cb406449b44052cfadbddef7513e026a70->leave($__internal_3fab6af8bafe6506c9cdf87059d676cb406449b44052cfadbddef7513e026a70_prof);

        
        $__internal_db3c9e1e7a662233142ea2f493f033dc8286d4173af57655621494ee0c20600e->leave($__internal_db3c9e1e7a662233142ea2f493f033dc8286d4173af57655621494ee0c20600e_prof);

    }

    public function getTemplateName()
    {
        return "bootstrap_4_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  672 => 181,  664 => 179,  660 => 178,  651 => 176,  649 => 175,  640 => 174,  628 => 169,  626 => 168,  624 => 167,  622 => 166,  618 => 165,  615 => 163,  613 => 162,  604 => 161,  593 => 155,  589 => 154,  574 => 153,  570 => 150,  567 => 147,  566 => 146,  565 => 145,  563 => 144,  561 => 143,  558 => 141,  556 => 140,  553 => 138,  551 => 137,  549 => 136,  547 => 135,  538 => 133,  528 => 130,  525 => 128,  522 => 126,  520 => 125,  518 => 124,  509 => 123,  498 => 117,  492 => 113,  491 => 112,  490 => 111,  486 => 110,  482 => 109,  479 => 107,  477 => 106,  470 => 102,  469 => 101,  468 => 100,  467 => 99,  463 => 98,  461 => 97,  452 => 96,  441 => 92,  439 => 91,  435 => 90,  432 => 88,  430 => 87,  428 => 86,  426 => 85,  417 => 84,  406 => 80,  404 => 79,  400 => 78,  397 => 76,  395 => 75,  393 => 74,  391 => 73,  382 => 72,  372 => 69,  370 => 68,  361 => 67,  351 => 64,  348 => 63,  345 => 62,  343 => 61,  334 => 60,  324 => 57,  321 => 55,  319 => 54,  310 => 53,  299 => 49,  297 => 48,  295 => 47,  290 => 46,  281 => 45,  271 => 42,  268 => 40,  266 => 39,  264 => 38,  255 => 37,  245 => 34,  242 => 32,  240 => 31,  238 => 30,  229 => 29,  219 => 26,  216 => 24,  214 => 23,  212 => 22,  203 => 21,  193 => 18,  190 => 16,  188 => 15,  186 => 14,  177 => 13,  167 => 10,  164 => 9,  161 => 8,  158 => 7,  156 => 6,  147 => 5,  137 => 174,  134 => 173,  131 => 171,  129 => 161,  126 => 160,  123 => 158,  121 => 133,  118 => 132,  116 => 123,  113 => 122,  110 => 120,  108 => 96,  105 => 95,  103 => 84,  100 => 83,  98 => 72,  95 => 71,  93 => 67,  91 => 60,  89 => 53,  86 => 52,  84 => 45,  81 => 44,  79 => 37,  76 => 36,  74 => 29,  71 => 28,  69 => 21,  66 => 20,  64 => 13,  61 => 12,  59 => 5,  56 => 4,  53 => 2,  14 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% use \"bootstrap_base_layout.html.twig\" %}

{# Widgets #}

{% block money_widget -%}
    {% if not valid %}
        {% set group_class = ' form-control is-invalid' %}
        {% set valid = true %}
    {% endif %}
    {{- parent() -}}
{%- endblock money_widget %}

{% block datetime_widget -%}
    {%- if widget != 'single_text' and not valid -%}
        {% set attr = attr|merge({class: (attr.class|default('') ~ ' form-control is-invalid')|trim}) -%}
        {% set valid = true %}
    {%- endif -%}
    {{- parent() -}}
{%- endblock datetime_widget %}

{% block date_widget -%}
    {%- if widget != 'single_text' and not valid -%}
        {% set attr = attr|merge({class: (attr.class|default('') ~ ' form-control is-invalid')|trim}) -%}
        {% set valid = true %}
    {%- endif -%}
    {{- parent() -}}
{%- endblock date_widget %}

{% block time_widget -%}
    {%- if widget != 'single_text' and not valid -%}
        {% set attr = attr|merge({class: (attr.class|default('') ~ ' form-control is-invalid')|trim}) -%}
        {% set valid = true %}
    {%- endif -%}
    {{- parent() -}}
{%- endblock time_widget %}

{% block dateinterval_widget -%}
    {%- if widget != 'single_text' and not valid -%}
        {% set attr = attr|merge({class: (attr.class|default('') ~ ' form-control is-invalid')|trim}) -%}
        {% set valid = true %}
    {%- endif -%}
    {{- parent() -}}
{%- endblock dateinterval_widget %}

{% block percent_widget -%}
    <div class=\"input-group{{ not valid ? ' form-control is-invalid' }}\">
        {% set valid = true %}
        {{- block('form_widget_simple') -}}
        <span class=\"input-group-addon\">%</span>
    </div>
{%- endblock percent_widget %}

{% block form_widget_simple -%}
    {% if type is not defined or type != 'hidden' %}
        {%- set attr = attr|merge({class: (attr.class|default('') ~ ' form-control' ~ (type|default('') == 'file' ? '-file' : ''))|trim}) -%}
    {% endif %}
    {{- parent() -}}
{%- endblock form_widget_simple %}

{%- block widget_attributes -%}
    {%- if not valid %}
        {% set attr = attr|merge({class: (attr.class|default('') ~ ' form-control is-invalid')|trim}) %}
    {% endif -%}
    {{ parent() }}
{%- endblock widget_attributes -%}

{% block button_widget -%}
    {%- set attr = attr|merge({class: (attr.class|default('btn-secondary') ~ ' btn')|trim}) -%}
    {{- parent() -}}
{%- endblock button_widget %}

{% block checkbox_widget -%}
    {%- set parent_label_class = parent_label_class|default(label_attr.class|default('')) -%}
    {%- set attr = attr|merge({class: (attr.class|default('') ~ ' form-check-input')|trim}) -%}
    {% if 'checkbox-inline' in parent_label_class %}
        {{- form_label(form, null, { widget: parent() }) -}}
    {% else -%}
        <div class=\"form-check{{ not valid ? ' form-control is-invalid' }}\">
            {{- form_label(form, null, { widget: parent() }) -}}
        </div>
    {%- endif -%}
{%- endblock checkbox_widget %}

{% block radio_widget -%}
    {%- set parent_label_class = parent_label_class|default(label_attr.class|default('')) -%}
    {%- set attr = attr|merge({class: (attr.class|default('') ~ ' form-check-input')|trim}) -%}
    {%- if 'radio-inline' in parent_label_class -%}
        {{- form_label(form, null, { widget: parent() }) -}}
    {%- else -%}
        <div class=\"form-check{{ not valid ? ' form-control is-invalid' }}\">
            {{- form_label(form, null, { widget: parent() }) -}}
        </div>
    {%- endif -%}
{%- endblock radio_widget %}

{% block choice_widget_expanded -%}
    {% if '-inline' in label_attr.class|default('') -%}
        {%- for child in form %}
            {{- form_widget(child, {
                parent_label_class: label_attr.class|default(''),
                translation_domain: choice_translation_domain,
                valid: valid,
            }) -}}
        {% endfor -%}
    {%- else -%}
        {%- if not valid -%}
            {%- set attr = attr|merge({class: (attr.class|default('') ~ ' form-control is-invalid')|trim}) %}
        {%- endif -%}
        <div {{ block('widget_container_attributes') }}>
            {%- for child in form %}
                {{- form_widget(child, {
                    parent_label_class: label_attr.class|default(''),
                    translation_domain: choice_translation_domain,
                    valid: true,
                }) -}}
            {% endfor -%}
        </div>
    {%- endif %}
{%- endblock choice_widget_expanded %}

{# Labels #}

{% block form_label -%}
    {%- if compound is defined and compound -%}
        {%- set element = 'legend' -%}
        {%- set label_attr = label_attr|merge({class: (label_attr.class|default('') ~ ' col-form-legend')|trim}) -%}
    {%- else -%}
        {%- set label_attr = label_attr|merge({class: (label_attr.class|default('') ~ ' form-control-label')|trim}) -%}
    {%- endif -%}
    {{- parent() -}}
{%- endblock form_label %}

{% block checkbox_radio_label -%}
    {#- Do not display the label if widget is not defined in order to prevent double label rendering -#}
    {%- if widget is defined -%}
        {%- set label_attr = label_attr|merge({class: (label_attr.class|default('') ~ ' form-check-label')|trim}) -%}
        {%- if required -%}
            {%- set label_attr = label_attr|merge({class: (label_attr.class|default('') ~ ' required')|trim}) -%}
        {%- endif -%}
        {%- if parent_label_class is defined -%}
            {%- set label_attr = label_attr|merge({class: (label_attr.class|default('') ~ ' ' ~ parent_label_class)|trim}) -%}
        {%- endif -%}
        {%- if label is not same as(false) and label is empty -%}
            {%- if label_format is not empty -%}
                {%- set label = label_format|replace({
                    '%name%': name,
                    '%id%': id,
                }) -%}
            {%- else -%}
                {%- set label = name|humanize -%}
            {%- endif -%}
        {%- endif -%}
        <label{% for attrname, attrvalue in label_attr %} {{ attrname }}=\"{{ attrvalue }}\"{% endfor %}>
            {{- widget|raw }} {{ label is not same as(false) ? (translation_domain is same as(false) ? label : label|trans({}, translation_domain)) -}}
        </label>
    {%- endif -%}
{%- endblock checkbox_radio_label %}

{# Rows #}

{% block form_row -%}
    {%- if compound is defined and compound -%}
        {%- set element = 'fieldset' -%}
    {%- endif -%}
    <{{ element|default('div') }} class=\"form-group\">
        {{- form_label(form) -}}
        {{- form_widget(form) -}}
        {{- form_errors(form) -}}
    </{{ element|default('div') }}>
{%- endblock form_row %}

{# Errors #}

{% block form_errors -%}
    {%- if errors|length > 0 -%}
    <div class=\"{% if form.parent %}invalid-feedback{% else %}alert alert-danger{% endif %}\">
        <ul class=\"list-unstyled mb-0\">
            {%- for error in errors -%}
                <li>{{ error.message }}</li>
            {%- endfor -%}
        </ul>
    </div>
    {%- endif %}
{%- endblock form_errors %}
", "bootstrap_4_layout.html.twig", "C:\\Users\\Natalia\\Provider\\vendor\\symfony\\symfony\\src\\Symfony\\Bridge\\Twig\\Resources\\views\\Form\\bootstrap_4_layout.html.twig");
    }
}
