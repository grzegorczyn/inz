<?php

/* base.html.twig */
class __TwigTemplate_820014a7d11e5630f7b8f96636ab25f9df9e043eb564847d32007105b80be4d2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_53d31c097bd5d44670c2bfaee77d1aa3e2688c6abd7e005cdd3be46fc3fed15b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_53d31c097bd5d44670c2bfaee77d1aa3e2688c6abd7e005cdd3be46fc3fed15b->enter($__internal_53d31c097bd5d44670c2bfaee77d1aa3e2688c6abd7e005cdd3be46fc3fed15b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_88d7f3c5aeeaca89e7dc18b73f72cb9e50c427beeed3c1dcdbbf29c10027b745 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_88d7f3c5aeeaca89e7dc18b73f72cb9e50c427beeed3c1dcdbbf29c10027b745->enter($__internal_88d7f3c5aeeaca89e7dc18b73f72cb9e50c427beeed3c1dcdbbf29c10027b745_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_53d31c097bd5d44670c2bfaee77d1aa3e2688c6abd7e005cdd3be46fc3fed15b->leave($__internal_53d31c097bd5d44670c2bfaee77d1aa3e2688c6abd7e005cdd3be46fc3fed15b_prof);

        
        $__internal_88d7f3c5aeeaca89e7dc18b73f72cb9e50c427beeed3c1dcdbbf29c10027b745->leave($__internal_88d7f3c5aeeaca89e7dc18b73f72cb9e50c427beeed3c1dcdbbf29c10027b745_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_12cfc5570a96cbc99dbd8933ab3067fa90ddde7a11b58e848be96748be7a080c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_12cfc5570a96cbc99dbd8933ab3067fa90ddde7a11b58e848be96748be7a080c->enter($__internal_12cfc5570a96cbc99dbd8933ab3067fa90ddde7a11b58e848be96748be7a080c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_b4f12d53ca2e0254d0903c7e3cc5434ef83f62013ada0cbeed4119c3ecba635c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b4f12d53ca2e0254d0903c7e3cc5434ef83f62013ada0cbeed4119c3ecba635c->enter($__internal_b4f12d53ca2e0254d0903c7e3cc5434ef83f62013ada0cbeed4119c3ecba635c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_b4f12d53ca2e0254d0903c7e3cc5434ef83f62013ada0cbeed4119c3ecba635c->leave($__internal_b4f12d53ca2e0254d0903c7e3cc5434ef83f62013ada0cbeed4119c3ecba635c_prof);

        
        $__internal_12cfc5570a96cbc99dbd8933ab3067fa90ddde7a11b58e848be96748be7a080c->leave($__internal_12cfc5570a96cbc99dbd8933ab3067fa90ddde7a11b58e848be96748be7a080c_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_ba88dc2b2ac89e6cd67a3daf9248f916af82a1f86a98b6861d65f5861df44fff = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ba88dc2b2ac89e6cd67a3daf9248f916af82a1f86a98b6861d65f5861df44fff->enter($__internal_ba88dc2b2ac89e6cd67a3daf9248f916af82a1f86a98b6861d65f5861df44fff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_e19c826a239644c26c6ac93e5646573617e8718e5e8191f2dbeae6ca6d8fdbb2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e19c826a239644c26c6ac93e5646573617e8718e5e8191f2dbeae6ca6d8fdbb2->enter($__internal_e19c826a239644c26c6ac93e5646573617e8718e5e8191f2dbeae6ca6d8fdbb2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_e19c826a239644c26c6ac93e5646573617e8718e5e8191f2dbeae6ca6d8fdbb2->leave($__internal_e19c826a239644c26c6ac93e5646573617e8718e5e8191f2dbeae6ca6d8fdbb2_prof);

        
        $__internal_ba88dc2b2ac89e6cd67a3daf9248f916af82a1f86a98b6861d65f5861df44fff->leave($__internal_ba88dc2b2ac89e6cd67a3daf9248f916af82a1f86a98b6861d65f5861df44fff_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_2e1bd91bb4c52ca3a76f4a10ecc6b616ca9a6e0ac113c65d80cae3d00d105438 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2e1bd91bb4c52ca3a76f4a10ecc6b616ca9a6e0ac113c65d80cae3d00d105438->enter($__internal_2e1bd91bb4c52ca3a76f4a10ecc6b616ca9a6e0ac113c65d80cae3d00d105438_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_2af956e10ee4e52851050f1d7e2df609c70df1d6abafb67f1865aa2477e67157 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2af956e10ee4e52851050f1d7e2df609c70df1d6abafb67f1865aa2477e67157->enter($__internal_2af956e10ee4e52851050f1d7e2df609c70df1d6abafb67f1865aa2477e67157_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_2af956e10ee4e52851050f1d7e2df609c70df1d6abafb67f1865aa2477e67157->leave($__internal_2af956e10ee4e52851050f1d7e2df609c70df1d6abafb67f1865aa2477e67157_prof);

        
        $__internal_2e1bd91bb4c52ca3a76f4a10ecc6b616ca9a6e0ac113c65d80cae3d00d105438->leave($__internal_2e1bd91bb4c52ca3a76f4a10ecc6b616ca9a6e0ac113c65d80cae3d00d105438_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_5a0163011caeac10f76ad77ddab7f712c877b122bf404b1b238777d17466320c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5a0163011caeac10f76ad77ddab7f712c877b122bf404b1b238777d17466320c->enter($__internal_5a0163011caeac10f76ad77ddab7f712c877b122bf404b1b238777d17466320c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_7ee4566491d5ee11708a07761a63da142f09d4c84087e991b18e0ec600f9aad5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7ee4566491d5ee11708a07761a63da142f09d4c84087e991b18e0ec600f9aad5->enter($__internal_7ee4566491d5ee11708a07761a63da142f09d4c84087e991b18e0ec600f9aad5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_7ee4566491d5ee11708a07761a63da142f09d4c84087e991b18e0ec600f9aad5->leave($__internal_7ee4566491d5ee11708a07761a63da142f09d4c84087e991b18e0ec600f9aad5_prof);

        
        $__internal_5a0163011caeac10f76ad77ddab7f712c877b122bf404b1b238777d17466320c->leave($__internal_5a0163011caeac10f76ad77ddab7f712c877b122bf404b1b238777d17466320c_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 11,  100 => 10,  83 => 6,  65 => 5,  53 => 12,  50 => 11,  48 => 10,  41 => 7,  39 => 6,  35 => 5,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        {% block body %}{% endblock %}
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "base.html.twig", "C:\\Users\\Natalia\\Provider\\app\\Resources\\views\\base.html.twig");
    }
}
