<?php

/* form_table_layout.html.twig */
class __TwigTemplate_80fd584c67593bb3a1e61150bb3a0744b8864948207c03171598203a68544a6c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $_trait_0 = $this->loadTemplate("form_div_layout.html.twig", "form_table_layout.html.twig", 1);
        // line 1
        if (!$_trait_0->isTraitable()) {
            throw new Twig_Error_Runtime('Template "'."form_div_layout.html.twig".'" cannot be used as a trait.');
        }
        $_trait_0_blocks = $_trait_0->getBlocks();

        $this->traits = $_trait_0_blocks;

        $this->blocks = array_merge(
            $this->traits,
            array(
                'form_row' => array($this, 'block_form_row'),
                'button_row' => array($this, 'block_button_row'),
                'hidden_row' => array($this, 'block_hidden_row'),
                'form_widget_compound' => array($this, 'block_form_widget_compound'),
            )
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_76042dce96bf3dc50ea78ada644a04c3df4810cceaccb4dc06bf286fc95c0996 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_76042dce96bf3dc50ea78ada644a04c3df4810cceaccb4dc06bf286fc95c0996->enter($__internal_76042dce96bf3dc50ea78ada644a04c3df4810cceaccb4dc06bf286fc95c0996_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "form_table_layout.html.twig"));

        $__internal_a0ce1f0a75ab80394dfe3e6de2dc75ed87bff156b0af7a3297ed793a8fb8eaa7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a0ce1f0a75ab80394dfe3e6de2dc75ed87bff156b0af7a3297ed793a8fb8eaa7->enter($__internal_a0ce1f0a75ab80394dfe3e6de2dc75ed87bff156b0af7a3297ed793a8fb8eaa7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "form_table_layout.html.twig"));

        // line 3
        $this->displayBlock('form_row', $context, $blocks);
        // line 15
        $this->displayBlock('button_row', $context, $blocks);
        // line 24
        $this->displayBlock('hidden_row', $context, $blocks);
        // line 32
        $this->displayBlock('form_widget_compound', $context, $blocks);
        
        $__internal_76042dce96bf3dc50ea78ada644a04c3df4810cceaccb4dc06bf286fc95c0996->leave($__internal_76042dce96bf3dc50ea78ada644a04c3df4810cceaccb4dc06bf286fc95c0996_prof);

        
        $__internal_a0ce1f0a75ab80394dfe3e6de2dc75ed87bff156b0af7a3297ed793a8fb8eaa7->leave($__internal_a0ce1f0a75ab80394dfe3e6de2dc75ed87bff156b0af7a3297ed793a8fb8eaa7_prof);

    }

    // line 3
    public function block_form_row($context, array $blocks = array())
    {
        $__internal_ff3ac71e09571d52ffed8582a2c5aee3b7d75fb2979d7807524b978ac7854557 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ff3ac71e09571d52ffed8582a2c5aee3b7d75fb2979d7807524b978ac7854557->enter($__internal_ff3ac71e09571d52ffed8582a2c5aee3b7d75fb2979d7807524b978ac7854557_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_row"));

        $__internal_5b56c2c9f3c588ce7235cdf387110ab659dd133a2f9661fdf45f9e64fc4b84f3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5b56c2c9f3c588ce7235cdf387110ab659dd133a2f9661fdf45f9e64fc4b84f3->enter($__internal_5b56c2c9f3c588ce7235cdf387110ab659dd133a2f9661fdf45f9e64fc4b84f3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_row"));

        // line 4
        echo "<tr>
        <td>";
        // line 6
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label');
        // line 7
        echo "</td>
        <td>";
        // line 9
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
        // line 10
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 11
        echo "</td>
    </tr>";
        
        $__internal_5b56c2c9f3c588ce7235cdf387110ab659dd133a2f9661fdf45f9e64fc4b84f3->leave($__internal_5b56c2c9f3c588ce7235cdf387110ab659dd133a2f9661fdf45f9e64fc4b84f3_prof);

        
        $__internal_ff3ac71e09571d52ffed8582a2c5aee3b7d75fb2979d7807524b978ac7854557->leave($__internal_ff3ac71e09571d52ffed8582a2c5aee3b7d75fb2979d7807524b978ac7854557_prof);

    }

    // line 15
    public function block_button_row($context, array $blocks = array())
    {
        $__internal_d9ea70c4fbc0a44e8ded901788d2a4b1a7d97f9b126704123dd9114514429285 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d9ea70c4fbc0a44e8ded901788d2a4b1a7d97f9b126704123dd9114514429285->enter($__internal_d9ea70c4fbc0a44e8ded901788d2a4b1a7d97f9b126704123dd9114514429285_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "button_row"));

        $__internal_8064277e184aa5c78d1a7cf234a0b6977a7446dba747e6d40b80e116d2dfea1e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8064277e184aa5c78d1a7cf234a0b6977a7446dba747e6d40b80e116d2dfea1e->enter($__internal_8064277e184aa5c78d1a7cf234a0b6977a7446dba747e6d40b80e116d2dfea1e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "button_row"));

        // line 16
        echo "<tr>
        <td></td>
        <td>";
        // line 19
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 20
        echo "</td>
    </tr>";
        
        $__internal_8064277e184aa5c78d1a7cf234a0b6977a7446dba747e6d40b80e116d2dfea1e->leave($__internal_8064277e184aa5c78d1a7cf234a0b6977a7446dba747e6d40b80e116d2dfea1e_prof);

        
        $__internal_d9ea70c4fbc0a44e8ded901788d2a4b1a7d97f9b126704123dd9114514429285->leave($__internal_d9ea70c4fbc0a44e8ded901788d2a4b1a7d97f9b126704123dd9114514429285_prof);

    }

    // line 24
    public function block_hidden_row($context, array $blocks = array())
    {
        $__internal_9d056c787ec984ff124160298215e14c6e5b506160f62c16824c952880fc816d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9d056c787ec984ff124160298215e14c6e5b506160f62c16824c952880fc816d->enter($__internal_9d056c787ec984ff124160298215e14c6e5b506160f62c16824c952880fc816d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "hidden_row"));

        $__internal_ee7177ca0a3a33084672ee48c75c3444b8532bc04960e284e461ddbe45b5f60a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ee7177ca0a3a33084672ee48c75c3444b8532bc04960e284e461ddbe45b5f60a->enter($__internal_ee7177ca0a3a33084672ee48c75c3444b8532bc04960e284e461ddbe45b5f60a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "hidden_row"));

        // line 25
        echo "<tr style=\"display: none\">
        <td colspan=\"2\">";
        // line 27
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 28
        echo "</td>
    </tr>";
        
        $__internal_ee7177ca0a3a33084672ee48c75c3444b8532bc04960e284e461ddbe45b5f60a->leave($__internal_ee7177ca0a3a33084672ee48c75c3444b8532bc04960e284e461ddbe45b5f60a_prof);

        
        $__internal_9d056c787ec984ff124160298215e14c6e5b506160f62c16824c952880fc816d->leave($__internal_9d056c787ec984ff124160298215e14c6e5b506160f62c16824c952880fc816d_prof);

    }

    // line 32
    public function block_form_widget_compound($context, array $blocks = array())
    {
        $__internal_16615999554d9ab4337b8c59960d3d92d363579fe4e212b4a8f84438ebb1dd9d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_16615999554d9ab4337b8c59960d3d92d363579fe4e212b4a8f84438ebb1dd9d->enter($__internal_16615999554d9ab4337b8c59960d3d92d363579fe4e212b4a8f84438ebb1dd9d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_widget_compound"));

        $__internal_7fab33fc6be8e7049d863c65d64d9348e4240bfc11737c0bdac80732cfe30de7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7fab33fc6be8e7049d863c65d64d9348e4240bfc11737c0bdac80732cfe30de7->enter($__internal_7fab33fc6be8e7049d863c65d64d9348e4240bfc11737c0bdac80732cfe30de7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_widget_compound"));

        // line 33
        echo "<table ";
        $this->displayBlock("widget_container_attributes", $context, $blocks);
        echo ">";
        // line 34
        if ((twig_test_empty($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "parent", array())) && (twig_length_filter($this->env, ($context["errors"] ?? $this->getContext($context, "errors"))) > 0))) {
            // line 35
            echo "<tr>
            <td colspan=\"2\">";
            // line 37
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
            // line 38
            echo "</td>
        </tr>";
        }
        // line 41
        $this->displayBlock("form_rows", $context, $blocks);
        // line 42
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'rest');
        // line 43
        echo "</table>";
        
        $__internal_7fab33fc6be8e7049d863c65d64d9348e4240bfc11737c0bdac80732cfe30de7->leave($__internal_7fab33fc6be8e7049d863c65d64d9348e4240bfc11737c0bdac80732cfe30de7_prof);

        
        $__internal_16615999554d9ab4337b8c59960d3d92d363579fe4e212b4a8f84438ebb1dd9d->leave($__internal_16615999554d9ab4337b8c59960d3d92d363579fe4e212b4a8f84438ebb1dd9d_prof);

    }

    public function getTemplateName()
    {
        return "form_table_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  168 => 43,  166 => 42,  164 => 41,  160 => 38,  158 => 37,  155 => 35,  153 => 34,  149 => 33,  140 => 32,  129 => 28,  127 => 27,  124 => 25,  115 => 24,  104 => 20,  102 => 19,  98 => 16,  89 => 15,  78 => 11,  76 => 10,  74 => 9,  71 => 7,  69 => 6,  66 => 4,  57 => 3,  47 => 32,  45 => 24,  43 => 15,  41 => 3,  14 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% use \"form_div_layout.html.twig\" %}

{%- block form_row -%}
    <tr>
        <td>
            {{- form_label(form) -}}
        </td>
        <td>
            {{- form_errors(form) -}}
            {{- form_widget(form) -}}
        </td>
    </tr>
{%- endblock form_row -%}

{%- block button_row -%}
    <tr>
        <td></td>
        <td>
            {{- form_widget(form) -}}
        </td>
    </tr>
{%- endblock button_row -%}

{%- block hidden_row -%}
    <tr style=\"display: none\">
        <td colspan=\"2\">
            {{- form_widget(form) -}}
        </td>
    </tr>
{%- endblock hidden_row -%}

{%- block form_widget_compound -%}
    <table {{ block('widget_container_attributes') }}>
        {%- if form.parent is empty and errors|length > 0 -%}
        <tr>
            <td colspan=\"2\">
                {{- form_errors(form) -}}
            </td>
        </tr>
        {%- endif -%}
        {{- block('form_rows') -}}
        {{- form_rest(form) -}}
    </table>
{%- endblock form_widget_compound -%}
", "form_table_layout.html.twig", "C:\\Users\\Natalia\\Provider\\vendor\\symfony\\symfony\\src\\Symfony\\Bridge\\Twig\\Resources\\views\\Form\\form_table_layout.html.twig");
    }
}
