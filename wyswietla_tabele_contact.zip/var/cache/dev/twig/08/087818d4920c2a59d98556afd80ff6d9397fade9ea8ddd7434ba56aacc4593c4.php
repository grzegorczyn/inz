<?php

/* @Twig/Exception/exception.atom.twig */
class __TwigTemplate_c6321f93feef2007d6d179703bf9db1307c45f4f4b931856918d6750d1f82368 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4463a4d6b613cd910874fa3600a0a4688277e5532743ea242e02f073a5eec7d3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4463a4d6b613cd910874fa3600a0a4688277e5532743ea242e02f073a5eec7d3->enter($__internal_4463a4d6b613cd910874fa3600a0a4688277e5532743ea242e02f073a5eec7d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.atom.twig"));

        $__internal_f6ca5920369caa3874667232d51b806c1be471c94bbc407058b25c6053069325 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f6ca5920369caa3874667232d51b806c1be471c94bbc407058b25c6053069325->enter($__internal_f6ca5920369caa3874667232d51b806c1be471c94bbc407058b25c6053069325_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.atom.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/exception.xml.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
";
        
        $__internal_4463a4d6b613cd910874fa3600a0a4688277e5532743ea242e02f073a5eec7d3->leave($__internal_4463a4d6b613cd910874fa3600a0a4688277e5532743ea242e02f073a5eec7d3_prof);

        
        $__internal_f6ca5920369caa3874667232d51b806c1be471c94bbc407058b25c6053069325->leave($__internal_f6ca5920369caa3874667232d51b806c1be471c94bbc407058b25c6053069325_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/exception.xml.twig', { exception: exception }) }}
", "@Twig/Exception/exception.atom.twig", "C:\\Users\\Natalia\\Provider\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception.atom.twig");
    }
}
