<?php

/* @Framework/Form/form_widget_simple.html.php */
class __TwigTemplate_bd2e1b68d49de8a52faf1b523d36bfb09e9674be8d46f12572b09c6464cdd1cb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_341a9a4ac6b1817fc7252ed04f6df3252d5f1f9060819e6ac8c77052c7397944 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_341a9a4ac6b1817fc7252ed04f6df3252d5f1f9060819e6ac8c77052c7397944->enter($__internal_341a9a4ac6b1817fc7252ed04f6df3252d5f1f9060819e6ac8c77052c7397944_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_simple.html.php"));

        $__internal_f80acede88e69e10b701d09e82012e8a9860c7ed1d243e90f3ee31ab97c0cb82 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f80acede88e69e10b701d09e82012e8a9860c7ed1d243e90f3ee31ab97c0cb82->enter($__internal_f80acede88e69e10b701d09e82012e8a9860c7ed1d243e90f3ee31ab97c0cb82_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_simple.html.php"));

        // line 1
        echo "<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
";
        
        $__internal_341a9a4ac6b1817fc7252ed04f6df3252d5f1f9060819e6ac8c77052c7397944->leave($__internal_341a9a4ac6b1817fc7252ed04f6df3252d5f1f9060819e6ac8c77052c7397944_prof);

        
        $__internal_f80acede88e69e10b701d09e82012e8a9860c7ed1d243e90f3ee31ab97c0cb82->leave($__internal_f80acede88e69e10b701d09e82012e8a9860c7ed1d243e90f3ee31ab97c0cb82_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_simple.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
", "@Framework/Form/form_widget_simple.html.php", "C:\\Users\\Natalia\\Provider\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_widget_simple.html.php");
    }
}
