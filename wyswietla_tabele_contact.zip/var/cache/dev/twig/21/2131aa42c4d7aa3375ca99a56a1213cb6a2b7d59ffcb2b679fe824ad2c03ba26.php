<?php

/* default/update.html.twig */
class __TwigTemplate_87a592dca4ab56b48b4ca8170ebda59110b40489c95411380c988525dfb82e32 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bb14e0bd355247d2a3108c34fcf1569fe35f640159622d64b2cc0a5b2d42ffca = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bb14e0bd355247d2a3108c34fcf1569fe35f640159622d64b2cc0a5b2d42ffca->enter($__internal_bb14e0bd355247d2a3108c34fcf1569fe35f640159622d64b2cc0a5b2d42ffca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/update.html.twig"));

        $__internal_01f9c4e6faf7eeaf3a7deb3344f7dc15d03437df2a8820eda62ab436a5a1b8fe = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_01f9c4e6faf7eeaf3a7deb3344f7dc15d03437df2a8820eda62ab436a5a1b8fe->enter($__internal_01f9c4e6faf7eeaf3a7deb3344f7dc15d03437df2a8820eda62ab436a5a1b8fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/update.html.twig"));

        // line 1
        echo "siema";
        
        $__internal_bb14e0bd355247d2a3108c34fcf1569fe35f640159622d64b2cc0a5b2d42ffca->leave($__internal_bb14e0bd355247d2a3108c34fcf1569fe35f640159622d64b2cc0a5b2d42ffca_prof);

        
        $__internal_01f9c4e6faf7eeaf3a7deb3344f7dc15d03437df2a8820eda62ab436a5a1b8fe->leave($__internal_01f9c4e6faf7eeaf3a7deb3344f7dc15d03437df2a8820eda62ab436a5a1b8fe_prof);

    }

    public function getTemplateName()
    {
        return "default/update.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("siema", "default/update.html.twig", "C:\\Users\\Natalia\\Provider\\app\\Resources\\views\\default\\update.html.twig");
    }
}
